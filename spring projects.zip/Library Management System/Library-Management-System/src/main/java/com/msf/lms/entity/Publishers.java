package com.msf.lms.entity;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Entity
@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class Publishers {
    @Id
    @GeneratedValue
    private Long id;
    private String name;
    private String address;
    @Column(name = "created_date")
    private LocalDate createdDate;
    @Column(name = "updated_date")
    private LocalDate updatedDate;
    @OneToMany(targetEntity = Books.class, cascade = CascadeType.ALL, orphanRemoval = true)
    @JoinColumn(name = "publisher_id", referencedColumnName = "id")
    @JsonManagedReference
    private List<Books> booksList;
}