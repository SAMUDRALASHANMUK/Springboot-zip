package com.msf.lms.controller;

import com.msf.lms.dto.PublisherRequest;
import com.msf.lms.entity.Publishers;
import com.msf.lms.exception.ResourceNotFoundException;
import com.msf.lms.service.PublisherServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/publishers")
public class PublisherController {

    @Autowired
    private PublisherServiceImpl publisherService;

    @PostMapping
    public Long createPublisher(@RequestBody @Valid PublisherRequest publisherRequest) {
        return publisherService.createPublisher(publisherRequest);
    }

    @GetMapping
    public List<Publishers> retrieveAllPublishers() throws ResourceNotFoundException {
        return publisherService.retrieveAllPublishers();
    }

    @GetMapping("/{id}")
    public Publishers retrievePublisherById(@PathVariable Long id) throws ResourceNotFoundException {
        return publisherService.retrievePublisherById(id);
    }

    @PutMapping("/{id}")
    public String updatePublisherById(@PathVariable Long id, @RequestBody @Valid PublisherRequest publisherRequest) throws ResourceNotFoundException {
        return publisherService.updatePublisherById(id, publisherRequest);
    }

    @DeleteMapping("/{id}")
    public String deletePublisherByID(@PathVariable Long id) throws ResourceNotFoundException {
        return publisherService.deletePublisherByID(id);
    }
}
