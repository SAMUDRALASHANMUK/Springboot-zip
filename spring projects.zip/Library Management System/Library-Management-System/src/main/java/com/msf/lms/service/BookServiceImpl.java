package com.msf.lms.service;

import com.msf.lms.dto.BookRequest;
import com.msf.lms.entity.Books;
import com.msf.lms.exception.ResourceNotFoundException;
import com.msf.lms.repository.BookRepository;
import com.msf.lms.repository.PublisherRepository;
import com.msf.lms.service.impl.BookService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.time.LocalDate;
import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookRepository bookRepository;
    @Autowired
    private PublisherRepository publisherRepository;

    @Override
    public Long createBook(@RequestBody @Valid BookRequest bookRequest) {
        Books books = Books.build(0L,
                bookRequest.getTitle(),
                bookRequest.getDescription(),
                bookRequest.getCategory(),
                LocalDate.now(),
                null,
                publisherRepository.getReferenceById(bookRequest.getPublisherId())
        );
        return bookRepository.save(books).getId();
    }

    @Override
    public List<Books> retrieveAllBooks() throws ResourceNotFoundException {
        List<Books> books = bookRepository.findAll();
        if (books.isEmpty()) {
            throw new ResourceNotFoundException("No Books found");
        } else {
            return books;
        }
    }

    @Override
    public Books retrieveBookById(Long id) throws ResourceNotFoundException {
        Books books = bookRepository.findById(id).orElse(null);
        if (books != null) {
            return books;
        } else {
            throw new ResourceNotFoundException("Oops Book not found");
        }
    }

    @Override
    public String updateBook(Long id, BookRequest bookRequest) throws ResourceNotFoundException {
        Books books = bookRepository.findById(id).orElse(null);
        if (books != null) {
            books.setTitle(bookRequest.getTitle());
            books.setDescription(bookRequest.getDescription());
            books.setCategory(bookRequest.getCategory());
            books.setUpdatedDate(LocalDate.now());
            bookRepository.save(books);
            return "Book Details Updated Successfully..";
        } else {
            throw new ResourceNotFoundException("Book Not Found");
        }
    }

    @Override
    public String deleteBook(Long id) throws ResourceNotFoundException {
        Books books = bookRepository.findById(id).orElse(null);
        if (books != null) {
            bookRepository.deleteById(id);
            return "Books Deleted...";
        } else {
            throw new ResourceNotFoundException("Books not found");
        }
    }
}
