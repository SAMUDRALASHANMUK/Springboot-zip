package com.msf.lms.dto;

import com.msf.lms.entity.Books;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;
import java.util.List;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class PublisherRequest {
    @NotNull(message = "Please provide an name")
    private String name;
    @NotNull(message = "Please provide an address")
    private String address;
    @NotNull(message = "Publisher must publish one book")
    private List<Books> booksList;
}
