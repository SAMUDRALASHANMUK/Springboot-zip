package com.msf.lms.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class BookRequest {
    @NotNull(message = "Please provide an title")
    private String title;
    @NotNull(message = "Please provide an description")
    private String description;
    @NotNull(message = "Please provide an category")
    private String category;
    private Long publisherId;
}
