package com.msf.lms.controller;

import com.msf.lms.dto.BookRequest;
import com.msf.lms.entity.Books;
import com.msf.lms.exception.ResourceNotFoundException;
import com.msf.lms.service.BookServiceImpl;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/books")
public class BookController {

    @Autowired
    private BookServiceImpl bookService;

    @PostMapping
    public Long createBook(@RequestBody @Valid BookRequest bookRequest) {
        return bookService.createBook(bookRequest);
    }

    @GetMapping
    public List<Books> retrieveAllBooks() throws ResourceNotFoundException {
        return bookService.retrieveAllBooks();
    }

    @GetMapping("/{id}")
    public Books retrieveBookById(@PathVariable Long id) throws ResourceNotFoundException {
        return bookService.retrieveBookById(id);
    }

    @PutMapping("/{id}")
    public String updateBook(@PathVariable Long id, @RequestBody @Valid BookRequest bookRequest) throws ResourceNotFoundException {
        return bookService.updateBook(id, bookRequest);
    }

    @DeleteMapping("/{id}")
    public String deleteBook(@PathVariable Long id) throws ResourceNotFoundException {
        return bookService.deleteBook(id);
    }
}
