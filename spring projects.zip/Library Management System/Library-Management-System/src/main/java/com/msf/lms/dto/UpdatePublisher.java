package com.msf.lms.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor(staticName = "build")
@NoArgsConstructor
public class UpdatePublisher {
    @NotNull(message = "Please provide an name")
    private String name;
    @NotNull(message = "Please provide an address")
    private String address;
}
