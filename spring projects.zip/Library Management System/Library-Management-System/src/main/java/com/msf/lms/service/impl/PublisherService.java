package com.msf.lms.service.impl;

import com.msf.lms.dto.PublisherRequest;
import com.msf.lms.entity.Publishers;
import com.msf.lms.exception.ResourceNotFoundException;

import java.util.List;

public interface PublisherService {
    Long createPublisher(PublisherRequest publisherRequest);

    List<Publishers> retrieveAllPublishers() throws ResourceNotFoundException;

    Publishers retrievePublisherById(Long id) throws ResourceNotFoundException;

    String updatePublisherById(Long id, PublisherRequest publisherRequest) throws ResourceNotFoundException;

    String deletePublisherByID(Long id) throws ResourceNotFoundException;
}
