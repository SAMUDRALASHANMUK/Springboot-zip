package com.msf.lms.service.impl;

import com.msf.lms.dto.BookRequest;
import com.msf.lms.entity.Books;
import com.msf.lms.exception.ResourceNotFoundException;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface BookService {


    Long createBook(BookRequest bookRequest);

    List<Books> retrieveAllBooks() throws ResourceNotFoundException;

    Books retrieveBookById(Long id) throws ResourceNotFoundException;

    String updateBook(Long id, BookRequest bookRequest) throws ResourceNotFoundException;

    String deleteBook(Long id) throws ResourceNotFoundException;
}
