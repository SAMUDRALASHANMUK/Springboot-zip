package com.msf.lms.service;

import com.msf.lms.dto.PublisherRequest;
import com.msf.lms.entity.Publishers;
import com.msf.lms.exception.ResourceNotFoundException;
import com.msf.lms.repository.BookRepository;
import com.msf.lms.repository.PublisherRepository;
import com.msf.lms.service.impl.PublisherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class PublisherServiceImpl implements PublisherService {
    @Autowired
    private PublisherRepository publisherRepository;
    @Autowired
    private BookRepository bookRepository;

    @Override
    public Long createPublisher(PublisherRequest publisherRequest) {
        Publishers publishers = Publishers.build(0L,
                publisherRequest.getName(),
                publisherRequest.getAddress(),
                LocalDate.now(),
                null,
                publisherRequest.getBooksList());
        return publisherRepository.save(publishers).getId();
    }

    @Override
    public List<Publishers> retrieveAllPublishers() throws ResourceNotFoundException {
        List<Publishers> publishers = publisherRepository.findAll();
        if (publishers.isEmpty()) {
            throw new ResourceNotFoundException("No Publishers found");
        } else {
            return publishers;
        }
    }

    @Override
    public Publishers retrievePublisherById(Long id) throws ResourceNotFoundException {
        Publishers publishers = publisherRepository.findById(id).orElse(null);
        if (publishers != null) {
            return publishers;
        } else {
            throw new ResourceNotFoundException("Oops Publisher not found");
        }
    }

    @Override
    public String updatePublisherById(Long id, PublisherRequest publisherRequest) throws ResourceNotFoundException {
        Publishers publishers = publisherRepository.findById(id).orElse(null);
        if (publishers != null) {
            publishers.setName(publisherRequest.getName());
            publishers.setAddress(publisherRequest.getAddress());
            publishers.setUpdatedDate(LocalDate.now());
            publisherRepository.save(publishers);
            return "Publisher Details Updated Successfully..";
        } else {
            throw new ResourceNotFoundException("Publisher Not Found");
        }
    }

    @Override
    public String deletePublisherByID(Long id) throws ResourceNotFoundException {
        Publishers publishers = publisherRepository.findById(id).orElse(null);
        if (publishers != null) {
            publisherRepository.deleteById(id);
            return "Publisher Deleted...";
        } else {
            throw new ResourceNotFoundException("Publisher not found");
        }
    }
}
