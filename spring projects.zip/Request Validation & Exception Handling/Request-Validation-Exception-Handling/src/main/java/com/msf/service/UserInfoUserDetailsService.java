package com.msf.service;

import com.msf.dto.UserRequest;
import com.msf.entity.User;
import com.msf.repository.UserRepository;
import lombok.extern.log4j.Log4j2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
@Log4j2
public class UserInfoUserDetailsService implements UserDetailsService {

    @Autowired
    UserRepository userDetailsRepository;

    @Override
    public UserDetails loadUserByUsername(String name) throws UsernameNotFoundException {
        log.info("Start of the `loadUserByUsername` method in `UserInfoUserDetailsService`.");

        Optional<UserDetails> userInfoByUserName = userDetailsRepository.findByName(name);

        log.info("Found a user by username in the `repository`. Loading user details using `UserInfoUserDetails` for username: {}", name);
        return userInfoByUserName.get();//call userInfoUserDetails method with username
    }
}