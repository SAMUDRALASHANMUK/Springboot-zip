package com.msf.training;

import lombok.extern.apachecommons.CommonsLog;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Developer {
    @Autowired
    Laptop laptop;

    public void build() {
        laptop.code();
        System.out.println("Hey We are learning springboot");
    }
}
