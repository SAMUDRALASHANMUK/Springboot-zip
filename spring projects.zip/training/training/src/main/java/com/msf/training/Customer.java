package com.msf.training;

import lombok.Data;

@Data

public class Customer {
    Long id;
    String name;
    String age;
}

