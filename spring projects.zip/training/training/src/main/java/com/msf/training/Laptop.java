package com.msf.training;

import org.springframework.stereotype.Component;

@Component
public class Laptop {
    public void code() {
        System.out.println("Hey I am Working");
    }
}
