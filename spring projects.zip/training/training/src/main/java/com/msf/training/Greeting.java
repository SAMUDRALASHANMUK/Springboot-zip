package com.msf.training;

public record Greeting(long id, String name) {

}