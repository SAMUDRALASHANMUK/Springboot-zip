package com.msf.Springboot.Learning.task.repository;

import com.msf.Springboot.Learning.task.model.Student1;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Student1Repository extends JpaRepository<Student1, Long> {
}
