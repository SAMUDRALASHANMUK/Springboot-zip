package com.msf.Springboot.Learning.task.repository;

import com.msf.Springboot.Learning.task.model.Course1;
import org.springframework.data.jpa.repository.JpaRepository;

public interface Course1Repository extends JpaRepository<Course1, Long> {
}
