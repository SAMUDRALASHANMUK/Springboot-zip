package com.msf.Springboot.Learning.task.service;

import com.msf.Springboot.Learning.task.model.Student;

import java.util.List;

public interface StudentService {
    List<Student> addData();
}
